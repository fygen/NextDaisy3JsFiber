export default function Page() {
    return (
        <main className="flex">  
            <nav>

            </nav>
            <h1 className="text-3xl font-bold underline">Hello, Next.js!</h1>

        </main>
    )
}